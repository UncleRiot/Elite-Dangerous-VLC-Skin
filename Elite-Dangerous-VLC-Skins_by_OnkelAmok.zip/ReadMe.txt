Orginal skin: CompactBlack by M.A.J.D.A
Adapted for Elite Dangerous: OnkelAmok

